import json
import os
import re
from typing import Sequence

from dotenv import load_dotenv
from langchain.agents import create_agent
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, ToolMessage
from langchain_ollama import ChatOllama

from tools import CARD_API_URL, OLLAMA_BASE_URL, RULE_SECTION_PATTERN, lookup_card, search_rules

load_dotenv()

SYSTEM_PROMPT = """You are an OPTCG rules assistant. Use the retrieved references
provided with the current question. Card API data supplies printed card facts;
official rules explain game mechanics. Always Call tools.
- For a specific ruling, prefer an explicit official Rules Q&A answer when returned.
  Pass the full user's question to search_rules for a specific ruling.
  State that Q&A answer and its source; do not add a reason the Q&A does not give.
- Printed card stats or text: call lookup_card with the card ID. For a single
  stat, pass field, for example field="power". If no card is found, say so.
  Copy printed stats from their API fields; do not derive them from card effects.
  A null field means no value is provided, not zero. Explain this in ordinary
  language, not as "power is null". Event cards have no printed power.
- Card interactions: use both tools.
For follow-ups, you may reuse tool results already in this conversation if they
answer the question. Otherwise call a tool. When reusing rules, cite the exact
rule section from that tool result in your answer.
Use the tool results, not memory or previous answers. Explain how the exact
rule's conditions and required actions apply. Timing and activation actions are
separate requirements: meeting the timing does not waive an action or cost.
Already being in an action's resulting state is not performing that action.
For state-change questions, also search for the rules governing that state change.
Do not invent rules or URLs.
Cite the returned rule section, PDF page, and source link.
For Rules Q&A, cite the PDF page and source link without inventing a rule number.
For a keyword definition, give at most two sentences describing that keyword; do not add other abilities
or infer exceptions. Read its meaning from the supplied definition, not its name.
Do not name example cards unless lookup_card has verified them. For card stats,
give only the requested stat and API source link. Keep answers brief.
If the tools do not settle the question, say you cannot verify the ruling."""

llm = ChatOllama(
    model=os.getenv("OLLAMA_CHAT_MODEL", "qwen3:1.7b"),
    base_url=OLLAMA_BASE_URL,
    temperature=0,
    reasoning=False,
    num_ctx=8192,
    num_predict=384,
)

agent = create_agent(
    model=llm,
    tools=[search_rules, lookup_card],
    system_prompt=SYSTEM_PROMPT,
)


def _is_tool_request_text(text: str) -> bool:
    def is_call(value):
        if isinstance(value, list):
            return any(is_call(item) for item in value)
        if not isinstance(value, dict):
            return False
        if "tool_calls" in value:
            return is_call(value["tool_calls"])
        call = value.get("function", value)
        return isinstance(call, dict) and isinstance(call.get("name"), str) and any(
            key in call for key in ("arguments", "args", "parameters")
        )

    decoder = json.JSONDecoder()
    for start in re.finditer(r"[\[{]", text):
        try:
            payload, _ = decoder.raw_decode(text[start.start():])
        except ValueError:
            continue
        if is_call(payload):
            return True
    return False


def invoke_agent(messages: Sequence[BaseMessage]) -> tuple[str, list[BaseMessage]]:
    question_index = next((i for i in range(len(messages) - 1, -1, -1)
                           if isinstance(messages[i], HumanMessage)), -1)
    if question_index < 0:
        raise ValueError("Ask an OPTCG question first.")
    question = messages[question_index].text
    card_ids = set(re.findall(r"\b[A-Z0-9]{1,6}-\d{3}\b", question.upper()))
    card_context = {}
    for card_id in sorted(card_ids):
        content = lookup_card.invoke({"card_id": card_id})
        if content:
            card_context[card_id] = content
    card_evidence = "\n\n".join(card_context.values()) or "No card ID was specified."
    rules_context = search_rules.invoke({"query": question})
    model_messages = list(messages)
    model_messages[question_index] = messages[question_index].model_copy(update={"content": (
        f"Question: {question}\n\nCard API reference retrieved for this question:\n"
        f"{card_evidence}\n\n"
        f"Official reference retrieved for this question:\n{rules_context}"
    )})
    result = agent.invoke({"messages": model_messages})
    output_messages = result.get("messages", [])
    if output_messages and isinstance(output_messages[-1], AIMessage) and _is_tool_request_text(output_messages[-1].text):
        # One correction with the same agent; never execute JSON from plain text.
        retry_messages = list(model_messages)
        retry_messages[question_index] = model_messages[question_index].model_copy(update={"content": (
            model_messages[question_index].text + "\n\nThe card and rules references are already "
            "provided above. Give the final answer in plain language. Do not print a tool "
            "request or tool-call JSON. Use actual tool calling only if more evidence is needed."
        )})
        result = agent.invoke({"messages": retry_messages})
        output_messages = result.get("messages", [])
        if output_messages and isinstance(output_messages[-1], AIMessage) and _is_tool_request_text(output_messages[-1].text):
            raise RuntimeError("The model returned a tool request instead of an answer. The request was not displayed; please try again.")
    if not output_messages:
        raise RuntimeError("The agent did not finish its answer. Please try again.")
    # Keep the user's original question in history, without accumulating RAG text.
    if question_index < len(output_messages) and isinstance(output_messages[question_index], HumanMessage):
        output_messages[question_index] = output_messages[question_index].model_copy(
            update={"content": messages[question_index].content}
        )
    final_message = output_messages[-1]
    if (
        not isinstance(final_message, AIMessage)
        or final_message.tool_calls
        or not final_message.text.strip()
    ):
        raise RuntimeError("The agent did not finish its answer. Please try again.")
    tool_results = [message for message in output_messages
                    if isinstance(message, ToolMessage) and message.status != "error"]
    has_rules_context = bool(re.search(
        r"(?:Comprehensive Rules|Rules Q&A) p\. \d+ \([^\n]*PDF: https://en\.onepiece-cardgame\.com/",
        rules_context,
    ))
    if not tool_results and not has_rules_context and not card_context:
        raise RuntimeError("The agent did not consult a source, so its answer was not shown. Please try again.")
    fresh_tools = [message for message in output_messages[len(messages):]
                   if isinstance(message, ToolMessage) and message.status != "error"]
    if not fresh_tools and not card_ids and not has_rules_context:
        cited_prior_rule = any(
            re.search(r"(?<![\d-])" + re.escape(section) + r"(?![\d-])", final_message.text)
            for message in tool_results if message.name == "search_rules"
            for section in RULE_SECTION_PATTERN.findall(message.text)
        )
        cited_prior_qa = any(
            source in final_message.text
            for message in tool_results if message.name == "search_rules" and "Rules Q&A p." in message.text
            for source in re.findall(r"PDF: (https://en\.onepiece-cardgame\.com/[^\s)]+qa_rules\.pdf[^\s)]*)", message.text)
        )
        if not cited_prior_rule and not cited_prior_qa:
            raise RuntimeError(
                "The agent did not consult a source or cite a previously retrieved rule, "
                "so its answer was not shown. Please try again."
            )
    for card_id in card_ids:
        card_results = [*card_context.values(), *[
            message.text for message in tool_results if message.name == "lookup_card"
        ]]
        not_found = f"The OPTCG card API returned no card for ID {card_id}."
        if any(not_found in content for content in card_results):
            output_messages[-1] = final_message.model_copy(update={"content": not_found})
            return not_found, output_messages
        source = f"API source: {CARD_API_URL.format(card_id=card_id)}"
        if not any(source in content for content in card_results):
            raise RuntimeError(
                f"The agent did not verify {card_id} with lookup_card, so its answer was not shown."
            )
    answer = final_message.text
    for card_id in sorted(card_ids):
        source = CARD_API_URL.format(card_id=card_id)
        if source not in answer:
            answer += f"\n\n[{card_id} card data]({source})"
    # Source links come from actual tool output, even if the model omits them.
    references = ([rules_context] if not card_ids else []) + [
        message.text for message in fresh_tools if message.name == "search_rules"
    ]
    for reference in references:
        for title, page, source in re.findall(
            r"(Comprehensive Rules|Rules Q&A) p\. (\d+) \([^\n]*?PDF: (https://en\.onepiece-cardgame\.com/[^\s)]+)\)",
            reference,
        ):
            if source not in answer:
                answer += f"\n\n[{title}, p. {page}]({source}#page={page})"
    output_messages[-1] = final_message.model_copy(update={"content": answer})
    return answer, output_messages


def main() -> None:
    question = input("Ask an OPTCG rules or card question: ")
    answer, _ = invoke_agent([HumanMessage(content=question)])
    print(answer)


if __name__ == "__main__":
    main()
