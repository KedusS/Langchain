# OPTCG Rules Assistant

A minimal LangChain `create_agent` chat assistant for One Piece Card Game rules
and card lookups. The agent chooses whether to search the official Comprehensive
Rules and Rules Q&A PDFs, look up a card ID, or use both tools. The model is instructed to cite
rule sections retrieved from the index. As with any language model, verify
important rulings against the cited official rules.

The agent follows Eden Marco's [search-agent course example](https://github.com/emarco177/langchain-course/blob/project/search-agent/main.py):
a chat model, tools, and `create_agent`. It uses Ollama in place of the example's
OpenAI model, with a rules-retrieval tool and a card-lookup tool in place of
general web search. Answers and source links are returned as normal text;
the optional structured-output schema is omitted because the local model did
not reliably return it. There is no custom router, second formatting model
call, or direct-answer bypass.

Streamlit stores the full LangChain message history between turns, including
assistant tool calls and their results. The displayed chat is stored separately.
Use **New conversation** to clear both histories.
References are retrieved before each answer: official rules for the question,
and card API records for card IDs explicitly included in it. The agent can
call its tools for additional evidence. This avoids depending on the small
model to initiate every lookup. The agent still writes the answer.
Follow-ups may reuse actual tool results in that history. A rules answer that
does not make a new tool call must cite a rule section from an earlier
`search_rules` result. Previous assistant text alone does not count as evidence.

## Setup

Requires Python 3.11+ and [uv](https://docs.astral.sh/uv/).

If `uv` is not installed, install it on Linux/macOS and add it to the current
shell's `PATH`:

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
export PATH="$HOME/.local/bin:$PATH"
uv --version
```

Alternatively, open a new terminal after the installer finishes, then check
that `uv --version` works.

From the repository root, enter the project directory and install dependencies:

```bash
cd search-agent
uv sync
```

Install and start [Ollama](https://ollama.com/download) on the same machine
where this app is running. Pull one chat model and one embedding model:

```bash
ollama pull qwen3:1.7b
ollama pull nomic-embed-text
```

Start the Ollama server in a separate Codespace terminal and leave that terminal
running:

```bash
ollama serve
```

By default, the app connects to `http://localhost:11434`.
If you are using Codespaces or another remote dev container, Ollama must be
running inside that environment or `OLLAMA_BASE_URL` must point to a server it
can reach; `localhost` refers to the dev container, not your personal computer.
Optionally configure a different server or model names in a `.env` file:

```dotenv
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_CHAT_MODEL=qwen3:1.7b
OLLAMA_EMBEDDING_MODEL=nomic-embed-text
```

Download and index the current Comprehensive Rules and Rules Q&A PDFs linked
from the official rules and FAQ pages. This also creates a local Chroma database in `chroma/`:

```bash
uv run python ingestion.py
```

Start the chat UI:

```bash
uv run streamlit run streamlit_app.py
```

Both the chat model and embeddings run locally through Ollama; no OpenAI API key
or paid model API is used. The first ingestion downloads the rules PDF and
creates local embeddings, which can take a few minutes. The `search_rules` tool
uses the local Chroma index containing both official documents. Explicit Rules
Q&A answers are preferred when they directly address the question. `lookup_card` uses the public, unauthenticated
[OPTCG API](https://optcgapi.com/documentation) and accepts IDs such as
`OP01-001` or `P-001`. Neither tool requires a separate API key. The rules PDF
and Chroma database are local files and are excluded from version control.

Keyword definitions match the indexed rule heading and use the complete source
PDF page, so a definition split across text chunks is still retrieved in full.
Situation questions continue to use vector search.

To refresh the local rules index when the official PDF changes, run
`uv run python ingestion.py` again.

Run the agent-response and UI checks with:

```bash
uv run python -m unittest test_rules_grounding.py
```

These checks use mocked model responses. They verify wiring and rendering,
not the accuracy of live rulings. The previous live test with `qwen3:1.7b`
retrieved relevant rules but interpreted a Blocker ruling incorrectly, so
successful retrieval and citations alone do not establish answer accuracy.

## CLI

For a one-question terminal session instead of Streamlit:

```bash
uv run python main.py
```

The model remains `qwen3:1.7b`. Source-use and citation checks do not verify
that the model correctly interprets the retrieved text.

Tool-call JSON printed as answer text gets one correction using the same agent.
If it repeats, the app reports an error instead of displaying the request as an
answer. Missing card fields are represented as `null`, not inferred from card
effects (for example, an Event card has no printed power).
