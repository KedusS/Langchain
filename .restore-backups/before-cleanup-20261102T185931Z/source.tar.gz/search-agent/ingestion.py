import re
from io import BytesIO
from urllib.parse import urljoin

import requests
from dotenv import load_dotenv
from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from pypdf import PdfReader

from tools import (
    CHROMA_DIR,
    COLLECTION_NAME,
    PROJECT_DIR,
    RULES_PAGE_URL,
    get_embeddings,
)

load_dotenv()

PDF_PATH = PROJECT_DIR / "data" / "rule_comprehensive.pdf"
QA_PATH = PROJECT_DIR / "data" / "qa_rules.pdf"


def download_official_pdf(page_url: str, filename: str) -> tuple[bytes, str]:
    page_response = requests.get(page_url, timeout=20)
    page_response.raise_for_status()
    pattern = re.compile(
        r"""href=["']([^"']*""" + re.escape(filename) + r"""(?:\?[^"']*)?)["']""",
        re.IGNORECASE,
    )
    match = pattern.search(page_response.text)
    if match is None:
        raise RuntimeError(f"No {filename} link was found on {page_url}.")
    pdf_url = urljoin(page_url, match.group(1))
    pdf_response = requests.get(pdf_url, timeout=30)
    pdf_response.raise_for_status()
    if not pdf_response.content.startswith(b"%PDF-"):
        raise RuntimeError(f"The official download was not a PDF: {pdf_url}")
    return pdf_response.content, pdf_url


def download_official_rules_pdf() -> tuple[bytes, str]:
    return download_official_pdf(RULES_PAGE_URL, "rule_comprehensive.pdf")


def ingest_rules() -> int:
    pdf_content, pdf_url = download_official_rules_pdf()
    qa_content, qa_url = download_official_pdf(
        urljoin(RULES_PAGE_URL, "faq/"), "qa_rules.pdf"
    )
    documents = []
    for content, source, title in [
        (pdf_content, pdf_url, "Comprehensive Rules"),
        (qa_content, qa_url, "Rules Q&A"),
    ]:
        reader = PdfReader(BytesIO(content))
        pages = [
            Document(page_content=text, metadata={
                "page": number, "source": source, "title": title,
            })
            for number, page in enumerate(reader.pages)
            if (text := page.extract_text()) and text.strip()
        ]
        if not pages:
            raise RuntimeError(f"No readable text was found in {title}.")
        documents.extend(pages)

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=150,
        add_start_index=True,
    )
    qa_splitter = RecursiveCharacterTextSplitter(
        chunk_size=300,
        chunk_overlap=50,
        add_start_index=True,
    )
    chunks = []
    for document in documents:
        selected_splitter = qa_splitter if document.metadata["title"] == "Rules Q&A" else splitter
        chunks.extend(selected_splitter.split_documents([document]))
    if not chunks:
        raise RuntimeError("The official rules PDF produced no searchable text.")

    embeddings = get_embeddings()
    if CHROMA_DIR.exists():
        existing_store = Chroma(
            collection_name=COLLECTION_NAME,
            persist_directory=str(CHROMA_DIR),
            embedding_function=embeddings,
        )
        existing_store.delete_collection()

    CHROMA_DIR.mkdir(parents=True, exist_ok=True)
    Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        collection_name=COLLECTION_NAME,
        persist_directory=str(CHROMA_DIR),
    )
    PDF_PATH.parent.mkdir(parents=True, exist_ok=True)
    PDF_PATH.write_bytes(pdf_content)
    QA_PATH.write_bytes(qa_content)

    print(f"Indexed {len(chunks)} chunks from {pdf_url} and {qa_url}")
    print(f"Local Chroma index: {CHROMA_DIR}")
    return len(chunks)


if __name__ == "__main__":
    ingest_rules()
