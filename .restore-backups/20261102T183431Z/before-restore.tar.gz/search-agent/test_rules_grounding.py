"""Check agent text responses and Streamlit rendering without structured output."""
import unittest
from unittest.mock import patch

from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from streamlit.testing.v1 import AppTest
from langchain_core.documents import Document

import main
from tools import lookup_card, search_rules
from ollama import ResponseError


class AgentResponseTests(unittest.TestCase):
    def setUp(self):
        rules_patch = patch.object(main, "search_rules")
        self.rules = rules_patch.start()
        self.addCleanup(rules_patch.stop)
        self.rules.invoke.return_value = "No sufficiently relevant passage was found."
        cards_patch = patch.object(main, "lookup_card")
        self.cards = cards_patch.start()
        self.addCleanup(cards_patch.stop)
        self.cards.invoke.return_value = ""

    def test_incomplete_json_is_not_accepted_as_a_text_answer(self):
        for text in ['{"card_power":', '[{"card_power": "5000"', '["4000",']:
            with self.subTest(text=text):
                self.assertTrue(main._needs_text_answer(text))

    def test_plain_text_and_source_links_are_not_treated_as_json(self):
        for text in ['["Blocker" rules](https://example.com) explain attack redirection.',
                     '["Blocker"](https://example.com)', 'The powers are [4000, 5000].']:
            with self.subTest(text=text):
                self.assertFalse(main._needs_text_answer(text))
        for text in ['Card data: {"card_power":"5000"}', 'Data: [{"card_power":"5000"}]',
                     'lookup_card(card_id="OP02-023", field="power")']:
            with self.subTest(text=text):
                self.assertTrue(main._needs_text_answer(text))

    def test_model_server_error_is_displayed_as_a_text_error(self):
        with patch.object(main, "agent") as agent:
            agent.invoke.side_effect = ResponseError("The local model is unavailable.", status_code=500)
            app = AppTest.from_file("streamlit_app.py", default_timeout=60).run()
            app.chat_input[0].set_value("What does Blocker do?").run()
        self.assertFalse(app.exception)
        self.assertIn("local model is unavailable", app.error[0].value)

    def test_tool_request_text_formats_are_recognized(self):
        request = '{"name":"lookup_card","arguments":{"card_id":"OP02-023","field":"power"}}'
        for text in [request, f"```json\n{request}\n```", f"<tool_call>\n{request}\n</tool_call>",
                     f'{{"tool_calls":[{request}]}}', f'[{request}]',
                     '{"function":{"name":"lookup_card","arguments":"{}"}}',
                     request + "\n[Card data](https://example.com)", '{"card_power":"5000"}', '[4000,5000]',
                     "I will look it up:\n" + request,
                     "```python\nlookup_card(card_id='OP02-023')\n```",
                     "Here is the lookup:\n```python\nlookup_card('OP02-023')\n```"]:
            with self.subTest(text=text):
                self.assertTrue(main._needs_text_answer(text))
        for text in ["OP01-001 has 5000 power.", "5000", "The powers are [4000, 5000].", "{incomplete"]:
            with self.subTest(text=text):
                self.assertFalse(main._needs_text_answer(text))

    def test_printed_tool_request_gets_one_agent_correction(self):
        question = HumanMessage(content="What is OP02-023’s power?")
        self.cards.invoke.return_value = (
            '{"card_set_id":"OP02-023","card_type":"Event","card_power":null}\n'
            'API source: https://optcgapi.com/api/sets/card/OP02-023/'
        )
        request = '{"name":"lookup_card","arguments":{"card_id":"OP02-023","field":"power"}}'
        replies = iter([request, "OP02-023 is an Event card and has no printed power."])
        with patch.object(main, "agent") as agent:
            agent.invoke.side_effect = lambda payload: {"messages": [
                *payload["messages"], AIMessage(content=next(replies))
            ]}
            answer, history = main.invoke_agent([question])
        self.assertEqual(agent.invoke.call_count, 2)
        self.cards.invoke.assert_called_once_with({"card_id": "OP02-023"})
        self.assertIn("no printed power", answer)
        self.assertNotIn('"arguments"', answer)
        self.assertIn(question.text, history[0].text)
        self.assertIn("Card API reference", history[0].text)
        self.assertTrue(all(request not in message.text for message in history))

    def test_repeated_tool_request_is_not_rendered_or_given_source_links(self):
        request = '{"name":"lookup_card","arguments":{"card_id":"OP02-023","field":"power"}}'
        self.cards.invoke.return_value = 'API source: https://optcgapi.com/api/sets/card/OP02-023/'
        with patch.object(main, "agent") as agent:
            agent.invoke.side_effect = lambda payload: {"messages": [
                *payload["messages"], AIMessage(content=request)
            ]}
            app = AppTest.from_file("streamlit_app.py", default_timeout=60).run()
            app.chat_input[0].set_value("What is OP02-023’s power?").run()
        self.assertEqual(agent.invoke.call_count, 2)
        self.assertFalse(app.exception)
        self.assertIn("did not produce a text answer", app.error[0].value)
        self.assertTrue(all('"arguments"' not in block.value for block in app.markdown))
        self.assertTrue(all("OP02-023 card data" not in block.value for block in app.markdown))

    def test_absent_card_power_is_explicitly_null(self):
        with patch("tools.requests.get") as get:
            get.return_value.status_code = 200
            get.return_value.json.return_value = {
                "card_set_id": "OP02-023", "card_type": "Event",
                "card_text": "A triggered effect gives +1000 power."
            }
            result = lookup_card.invoke({"card_id": "OP02-023", "field": "power"})
        self.assertIn('"card_power": null', result)
        self.assertNotIn("1000", result)
        self.assertIn("Event card, which has no printed power", result)

    def test_keyword_search_isolates_definition_from_other_abilities(self):
        document = Document(page_content=(
            "10-1-3. [Banish]\n10-1-3-1. Unrelated Banish text.\n"
            "10-1-4. [Blocker]\n10-1-4-1. Rest this card to replace the attack target.\n"
            "10-1-5. [Trigger]\n10-1-5-1. Unrelated Trigger text.\n"
        ), metadata={"page": 23, "source": "https://en.onepiece-cardgame.com/pdf/rule_comprehensive.pdf"})
        unrelated = Document(page_content="6-5-4. Main activation text.", metadata=document.metadata)
        with patch("tools._get_rules_vector_store") as store:
            store.return_value.similarity_search_with_relevance_scores.return_value = [
                (document, 0.8), (unrelated, 0.5)
            ]
            result = search_rules.invoke({"query": "Blocker"})
        self.assertIn("10-1-4-1", result)
        self.assertIn("replace the attack target", result)
        self.assertNotIn("Banish", result)
        self.assertNotIn("Trigger", result)
        self.assertNotIn("Main activation", result)

    def test_interaction_search_keeps_supplementary_rules(self):
        document = Document(page_content=(
            "10-1-4. [Blocker]\n10-1-4-1. Blocker definition.\n"
            "7-1-2. Additional battle timing text.\n"
        ), metadata={"page": 23, "source": "rules.pdf"})
        with patch("tools._get_rules_vector_store") as store:
            store.return_value.similarity_search_with_relevance_scores.return_value = [(document, 0.8)]
            result = search_rules.invoke({"query": "Blocker battle timing"})
        self.assertIn("Additional battle timing", result)

    def test_rules_qa_is_labelled_correctly_for_a_ruling_search(self):
        definition = Document(page_content="10-1-4. [Blocker]\n10-1-4-1. Rest this card.",
                              metadata={"page": 23, "source": "rules.pdf"})
        qa = Document(page_content="Can a rested Character activate Blocker? No, you cannot.",
                      metadata={"page": 4, "source": "https://en.onepiece-cardgame.com/pdf/qa_rules.pdf", "title": "Rules Q&A"})
        with patch("tools._get_rules_vector_store") as store:
            store.return_value.similarity_search_with_relevance_scores.return_value = [(definition, 0.8), (qa, 0.7)]
            result = search_rules.invoke({"query": "Blocker rules and Q&A"})
        self.assertIn("Rules Q&A p. 5", result)
        self.assertIn("No, you cannot", result)

    def test_exact_qa_question_is_preferred_over_a_different_resting_condition(self):
        source = "https://en.onepiece-cardgame.com/pdf/qa_rules.pdf"
        different = Document(page_content=(
            'Do effects that read "cannot be rested" mean that affected Characters cannot activate [Blocker]?\n'
            'Yes, they cannot activate Blocker.'
        ), metadata={"page": 9, "source": source, "title": "Rules Q&A"})
        exact = Document(page_content=(
            'Keyword Effects\nCan I activate the [Blocker] of a rested Character? No, you cannot.\n'
            'Keyword Effects\nCan I choose not to trash a Life card with Banish?\nNo, you cannot.'
        ), metadata={"page": 4, "source": source, "title": "Rules Q&A"})
        with patch("tools._get_rules_vector_store") as store:
            store.return_value.similarity_search_with_relevance_scores.return_value = [(different, 0.8), (exact, 0.7)]
            result = search_rules.invoke({"query": "Can an already-rested character activate Blocker?"})
        self.assertIn("Rules Q&A p. 5", result)
        self.assertNotIn("cannot be rested", result)
        self.assertNotIn("Banish", result)

    def test_official_qa_source_can_be_reused_for_follow_up(self):
        source = "https://en.onepiece-cardgame.com/pdf/qa_rules.pdf?20250228"
        history = [HumanMessage(content="Can a rested Character activate Blocker?"),
            ToolMessage(name="search_rules", tool_call_id="qa-1", content=(
                f"Rules Q&A p. 5 (PDF: {source})\nQuestion: Can a rested Character activate Blocker? Answer: No."
            )), AIMessage(content="No."), HumanMessage(content="Can you confirm that?")]
        answer = f"The official Rules Q&A says no: {source}"
        with patch.object(main, "agent") as agent:
            agent.invoke.return_value = {"messages": [*history, AIMessage(content=answer)]}
            result, _ = main.invoke_agent(history)
        self.assertEqual(result, answer)

    def test_missing_source_link_is_added_from_actual_tool_result(self):
        question = HumanMessage(content="Can an already-rested character activate Blocker?")
        source = "https://en.onepiece-cardgame.com/pdf/qa_rules.pdf?20250228"
        with patch.object(main, "agent") as agent:
            agent.invoke.return_value = {"messages": [question,
                ToolMessage(name="search_rules", tool_call_id="qa-1", content=(
                    f"Rules Q&A p. 5 (relevance 0.69; PDF: {source})\n"
                    "Can I activate the [Blocker] of a rested Character? No, you cannot."
                )), AIMessage(content="An already-rested character cannot activate Blocker.")]}
            answer, history = main.invoke_agent([question])
        self.assertIn(f"[Rules Q&A, p. 5]({source}#page=5)", answer)
        self.assertEqual(history[-1].text, answer)

    def test_single_stat_tool_returns_only_requested_field(self):
        with patch("tools.requests.get") as get:
            get.return_value.status_code = 200
            get.return_value.json.return_value = [{
                "card_set_id": "OP01-001", "card_power": "5000",
                "card_text": "An unrelated effect", "card_name": "Zoro",
            }]
            result = lookup_card.invoke({"card_id": "OP01-001", "field": "power"})
        self.assertIn('"card_power": "5000"', result)
        self.assertNotIn("card_text", result)
        self.assertIn("API source:", result)

    def test_full_card_lookup_still_returns_effects_for_rulings(self):
        with patch("tools.requests.get") as get:
            get.return_value.status_code = 200
            get.return_value.json.return_value = {
                "card_set_id": "OP01-001", "card_power": "5000", "card_text": "Example effect"
            }
            result = lookup_card.invoke({"card_id": "OP01-001"})
        self.assertIn("Example effect", result)

    def test_question_is_sent_to_agent_and_text_answer_is_returned(self):
        question = HumanMessage(content="What is OP01-001's power?")
        answer = "OP01-001 has 5000 power. [Source](https://optcgapi.com/api/sets/card/OP01-001/)"
        with patch.object(main, "agent") as agent:
            agent.invoke.return_value = {"messages": [question,
                ToolMessage(content="Power: 5000\nAPI source: https://optcgapi.com/api/sets/card/OP01-001/", name="lookup_card", tool_call_id="card-1"),
                AIMessage(content=answer)]}
            result, history = main.invoke_agent([question])
        agent.invoke.assert_called_once()
        self.assertIn(question.text, agent.invoke.call_args.args[0]["messages"][-1].text)
        self.assertIn("Official reference", agent.invoke.call_args.args[0]["messages"][-1].text)
        self.assertIn(question.text, history[0].text)
        self.assertIn("Card API reference", history[0].text)
        self.assertEqual(result, answer)

    def test_content_blocks_are_supported(self):
        with patch.object(main, "agent") as agent:
            agent.invoke.return_value = {"messages": [HumanMessage(content="Explain Blocker."),
                ToolMessage(content="Rule 10-1-4-1", name="search_rules", tool_call_id="rules-1"),
                AIMessage(content=[
                {"type": "text", "text": "See rule 10-1-4-1, page 24."}
            ])]}
            answer, history = main.invoke_agent([HumanMessage(content="Explain Blocker.")])
        self.assertIn("10-1-4-1", answer)

    def test_missing_final_answer_is_reported_clearly(self):
        with patch.object(main, "agent") as agent:
            agent.invoke.return_value = {"messages": []}
            with self.assertRaisesRegex(RuntimeError, "did not finish"):
                main.invoke_agent([HumanMessage(content="Explain Blocker.")])

    def test_unfinished_tool_call_is_not_displayed_as_answer(self):
        with patch.object(main, "agent") as agent:
            agent.invoke.return_value = {"messages": [AIMessage(content="", tool_calls=[
                {"id": "card-1", "name": "lookup_card", "args": {"card_id": "OP01-001"}}
            ])]}
            with self.assertRaisesRegex(RuntimeError, "did not finish"):
                main.invoke_agent([HumanMessage(content="What is OP01-001's power?")])

    def test_ui_displays_plain_text_answer_and_source_link(self):
        answer = "OP01-001 has 5000 power. [Source](https://optcgapi.com/api/sets/card/OP01-001/)"
        with patch.object(main, "agent") as agent:
            agent.invoke.return_value = {"messages": [HumanMessage(content="What is OP01-001’s power?"),
                ToolMessage(content="Power: 5000\nAPI source: https://optcgapi.com/api/sets/card/OP01-001/", name="lookup_card", tool_call_id="card-1"),
                AIMessage(content=answer)]}
            app = AppTest.from_file("streamlit_app.py", default_timeout=60).run()
            app.chat_input[0].set_value("What is OP01-001’s power?").run()
            self.assertFalse(app.exception)
            self.assertTrue(any(answer == item.value for item in app.markdown))
            self.assertEqual(app.session_state["messages"][-1]["answer"], answer)

    def test_second_chat_turn_preserves_tool_calls_and_results(self):
        def reply(payload):
            history = payload["messages"]
            card_id = "OP01-012" if "OP01-012" in history[-1].text else "OP01-001"
            power = "4000" if card_id == "OP01-012" else "5000"
            call_id = f"lookup-{card_id}"
            return {"messages": [*history,
                AIMessage(content="", tool_calls=[{
                    "id": call_id, "name": "lookup_card",
                    "args": {"card_id": card_id, "field": "power"},
                }]),
                ToolMessage(name="lookup_card", tool_call_id=call_id,
                    content=f"Power: {power}\nAPI source: https://optcgapi.com/api/sets/card/{card_id}/"),
                AIMessage(content=f"{card_id} has {power} power."),
            ]}

        with patch.object(main, "agent") as agent:
            agent.invoke.side_effect = reply
            app = AppTest.from_file("streamlit_app.py", default_timeout=60).run()
            app.chat_input[0].set_value("What is OP01-012’s power?").run()
            app.chat_input[0].set_value("What is OP01-001’s power?").run()
            self.assertFalse(app.exception)
            self.assertIn("OP01-001 has 5000 power.", app.session_state["messages"][-1]["answer"])
            second_input = agent.invoke.call_args_list[1].args[0]["messages"]
            self.assertEqual(len(second_input), 5)
            self.assertTrue(second_input[1].tool_calls)
            self.assertIsInstance(second_input[2], ToolMessage)
            self.assertIn("OP01-012", second_input[2].text)
            self.assertIn("OP01-001", second_input[-1].text)
            app.sidebar.button[0].click().run()
            self.assertEqual(app.session_state["messages"], [])
            self.assertEqual(app.session_state["agent_messages"], [])

    def test_rules_follow_up_works_when_model_makes_no_tool_call(self):
        rules_url = "https://en.onepiece-cardgame.com/pdf/rule_comprehensive.pdf"
        qa_url = "https://en.onepiece-cardgame.com/pdf/qa_rules.pdf"
        self.rules.invoke.side_effect = [
            f"Comprehensive Rules p. 24 (PDF: {rules_url})\n10-1-4-1. Rest this card to redirect the attack.",
            f"Rules Q&A p. 5 (PDF: {qa_url})\nCan a rested Character activate Blocker? No, you cannot.",
        ]
        answers = iter(["Blocker redirects an attack by resting the card.",
                        "No, an already-rested character cannot activate Blocker."])

        def reply(payload):
            return {"messages": [*payload["messages"], AIMessage(content=next(answers))]}

        with patch.object(main, "agent") as agent:
            agent.invoke.side_effect = reply
            app = AppTest.from_file("streamlit_app.py", default_timeout=60).run()
            app.chat_input[0].set_value("What does Blocker do?").run()
            app.chat_input[0].set_value("Can an already-rested character activate Blocker?").run()
        self.assertFalse(app.exception)
        self.assertFalse(app.error)
        self.assertIn("No, an already-rested", app.session_state["messages"][-1]["answer"])
        self.assertIn(f"{qa_url}#page=5", app.session_state["messages"][-1]["answer"])
        self.assertEqual(self.rules.invoke.call_count, 2)
        self.assertIn("No, you cannot", agent.invoke.call_args.args[0]["messages"][-1].text)
        self.assertTrue(any("Official reference" in m.text
                            for m in app.session_state["agent_messages"] if isinstance(m, HumanMessage)))
        self.assertTrue(all("Official reference" not in row["answer"]
                            for row in app.session_state["messages"] if row["role"] == "user"))

    def test_card_reference_supports_answer_when_model_skips_tool_call(self):
        question = HumanMessage(content="What is OP01-001’s power?")
        self.cards.invoke.return_value = (
            'Card OP01-001: {"card_power": "5000"}\n'
            'API source: https://optcgapi.com/api/sets/card/OP01-001/'
        )
        with patch.object(main, "agent") as agent:
            agent.invoke.side_effect = lambda payload: {"messages": [
                *payload["messages"], AIMessage(content="OP01-001 has 5000 power.")
            ]}
            answer, history = main.invoke_agent([question])
        self.cards.invoke.assert_called_once_with({"card_id": "OP01-001"})
        self.assertIn('"card_power": "5000"', agent.invoke.call_args.args[0]["messages"][-1].text)
        self.assertIn("5000", answer)
        self.assertIn("https://optcgapi.com/api/sets/card/OP01-001/", answer)
        self.assertIn(question.text, history[0].text)
        self.assertIn("Card API reference", history[0].text)

    def test_prefetched_missing_card_overrides_invented_stat(self):
        question = HumanMessage(content="What is OP99-999’s power?")
        missing = "The OPTCG card API returned no card for ID OP99-999."
        self.cards.invoke.return_value = missing
        with patch.object(main, "agent") as agent:
            agent.invoke.side_effect = lambda payload: {"messages": [
                *payload["messages"], AIMessage(content="It has 1000 power.")
            ]}
            answer, _ = main.invoke_agent([question])
        self.assertEqual(answer, missing)

    def test_card_json_is_corrected_to_a_text_answer(self):
        self.cards.invoke.return_value = 'API source: https://optcgapi.com/api/sets/card/OP01-001/'
        replies = iter(['{"card_power": "5000"}', "OP01-001 has 5000 power."])
        with patch.object(main, "agent") as agent:
            agent.invoke.side_effect = lambda payload: {"messages": [
                *payload["messages"], AIMessage(content=next(replies))
            ]}
            answer, history = main.invoke_agent([HumanMessage(content="What is OP01-001's power?")])
        self.assertEqual(agent.invoke.call_count, 2)
        self.assertIn("5000 power", answer)
        self.assertNotIn('"card_power"', answer)
        self.assertNotIn("Do not print", history[0].text)
        self.assertEqual(history[0].additional_kwargs["references"]["cards"], {
            "OP01-001": self.cards.invoke.return_value
        })

    def test_code_block_gets_the_same_single_text_correction(self):
        self.cards.invoke.return_value = 'API source: https://optcgapi.com/api/sets/card/OP01-001/'
        replies = iter(["```python\nlookup_card(card_id='OP01-001', field='power')\n```",
                        "OP01-001 has 5000 power."])
        with patch.object(main, "agent") as agent:
            agent.invoke.side_effect = lambda payload: {"messages": [
                *payload["messages"], AIMessage(content=next(replies))
            ]}
            answer, history = main.invoke_agent([HumanMessage(content="What is OP01-001's power?")])
        self.assertEqual(agent.invoke.call_count, 2)
        self.assertIn("5000 power", answer)
        self.assertNotIn("```", answer)
        self.assertNotIn("Do not print", history[0].text)

    def test_pronoun_follow_up_retains_the_actual_card_reference(self):
        source = "https://optcgapi.com/api/sets/card/OP02-023/"
        self.cards.invoke.return_value = (
            '{"card_set_id":"OP02-023","card_type":"Event","card_cost":"1","card_power":null}\n'
            f'API source: {source}'
        )
        replies = iter(["OP02-023 is an Event card with no printed power.",
                        f"Its cost is 1. Source: {source}"])
        with patch.object(main, "agent") as agent:
            agent.invoke.side_effect = lambda payload: {"messages": [
                *payload["messages"], AIMessage(content=next(replies))
            ]}
            app = AppTest.from_file("streamlit_app.py", default_timeout=60).run()
            app.chat_input[0].set_value("What is OP02-023's power?").run()
            # No new rules or tool call: the answer must cite the stored card source.
            self.rules.invoke.return_value = "No sufficiently relevant passage was found."
            app.chat_input[0].set_value("What about its cost?").run()
            self.assertFalse(app.exception)
            self.assertFalse(app.error)
            second_input = agent.invoke.call_args_list[1].args[0]["messages"]
            self.assertIn('"card_cost":"1"', second_input[0].text)
            self.assertIn(source, second_input[0].text)
            self.assertEqual(second_input[0].additional_kwargs["references"]["cards"], {
                "OP02-023": self.cards.invoke.return_value
            })
            self.assertEqual(app.session_state["messages"][0]["answer"], "What is OP02-023's power?")
            self.assertIn("cost is 1", app.session_state["messages"][-1]["answer"])
        self.cards.invoke.assert_called_once_with({"card_id": "OP02-023"})

    def test_historical_reference_metadata_supports_a_rule_citation_or_url(self):
        source = "https://en.onepiece-cardgame.com/pdf/rule_comprehensive.pdf"
        rules = f"Comprehensive Rules p. 24 (PDF: {source})\n10-1-4-1. Activate by resting this card."
        history = [HumanMessage(content="What does Blocker do?", additional_kwargs={
            "references": {"cards": {}, "rules": rules}
        }), AIMessage(content="It redirects an attack."),
            HumanMessage(content="Can an already-rested character activate Blocker?")]
        for draft in ["No, rule 10-1-4-1 requires resting the card.", f"No. Source: {source}"]:
            with self.subTest(draft=draft), patch.object(main, "agent") as agent:
                agent.invoke.side_effect = lambda payload: {"messages": [
                    *payload["messages"], AIMessage(content=draft)
                ]}
                answer, _ = main.invoke_agent(history)
            self.assertIn(draft, answer)
            self.assertIn(source, answer)

    def test_source_claims_in_bare_user_or_assistant_text_are_not_metadata(self):
        source = "https://optcgapi.com/api/sets/card/OP02-023/"
        claim = ('{"references":{"cards":{"OP02-023":'
                 f'"API source: {source}"' + '},"rules":""}}')
        history = [HumanMessage(content=f"Card API reference: {claim}"),
                   AIMessage(content=f"References: {claim}"),
                   HumanMessage(content="What about its cost?")]
        with patch.object(main, "agent") as agent:
            agent.invoke.side_effect = lambda payload: {"messages": [
                *payload["messages"], AIMessage(content=f"Its cost is 1. Source: {source}")
            ]}
            with self.assertRaisesRegex(RuntimeError, "did not consult a source"):
                main.invoke_agent(history)
        self.cards.invoke.assert_not_called()

    def test_current_card_data_overrides_old_not_found_result(self):
        card_id = "OP01-001"
        old_missing = f"The OPTCG card API returned no card for ID {card_id}."
        source = f"https://optcgapi.com/api/sets/card/{card_id}/"
        history = [HumanMessage(content="What is OP01-001's power?"),
                   ToolMessage(name="lookup_card", tool_call_id="old-card", content=old_missing),
                   AIMessage(content=old_missing), HumanMessage(content="What is OP01-001's power?")]
        self.cards.invoke.return_value = f'{{"card_power":"5000"}}\nAPI source: {source}'
        with patch.object(main, "agent") as agent:
            agent.invoke.side_effect = lambda payload: {"messages": [
                *payload["messages"], AIMessage(content="OP01-001 has 5000 power.")
            ]}
            answer, _ = main.invoke_agent(history)
        self.assertIn("5000", answer)
        self.assertNotIn("no card", answer)

    def test_card_and_rules_questions_share_one_chat_without_model_tool_calls(self):
        card_url = "https://optcgapi.com/api/sets/card/OP01-001/"
        rules_url = "https://en.onepiece-cardgame.com/pdf/rule_comprehensive.pdf"
        qa_url = "https://en.onepiece-cardgame.com/pdf/qa_rules.pdf"
        self.cards.invoke.return_value = f'{{"card_power": "5000"}}\nAPI source: {card_url}'
        self.rules.invoke.side_effect = [
            "No sufficiently relevant passage was found.",
            f"Comprehensive Rules p. 24 (PDF: {rules_url})\n10-1-4-1. Rest this card.",
            f"Rules Q&A p. 5 (PDF: {qa_url})\nNo, you cannot.",
        ]
        answers = iter(["OP01-001 has 5000 power.", "Blocker redirects an attack.",
                        "No, an already-rested character cannot activate Blocker."])
        with patch.object(main, "agent") as agent:
            agent.invoke.side_effect = lambda payload: {"messages": [
                *payload["messages"], AIMessage(content=next(answers))
            ]}
            app = AppTest.from_file("streamlit_app.py", default_timeout=60).run()
            for question in ["What is OP01-001’s power?", "What does Blocker do?",
                             "Can an already-rested character activate Blocker?"]:
                app.chat_input[0].set_value(question).run()
            self.assertFalse(app.exception)
            self.assertFalse(app.error)
            rows = app.session_state["messages"]
            self.assertEqual(len(rows), 6)
            self.assertIn("5000", rows[1]["answer"])
            self.assertIn(card_url, rows[1]["answer"])
            self.assertIn("No, an already-rested", rows[-1]["answer"])
            self.assertIn(qa_url, rows[-1]["answer"])
        self.cards.invoke.assert_called_once_with({"card_id": "OP01-001"})

    def test_fabricated_answer_without_tool_use_is_rejected(self):
        question = HumanMessage(content="What does Blocker do?")
        with patch.object(main, "agent") as agent:
            agent.invoke.return_value = {"messages": [question, AIMessage(
                content="Blocker prevents the opponent from playing cards. Rule 122."
            )]}
            with self.assertRaisesRegex(RuntimeError, "did not consult a source"):
                main.invoke_agent([question])

    def test_previous_turn_tool_results_do_not_count_as_fresh_evidence(self):
        history = [HumanMessage(content="Power of OP01-001?"),
            ToolMessage(content="5000", name="lookup_card", tool_call_id="old-card"),
            AIMessage(content="5000"), HumanMessage(content="What does Blocker do?")]
        with patch.object(main, "agent") as agent:
            agent.invoke.return_value = {"messages": [*history, AIMessage(content="A guess.")]}
            with self.assertRaisesRegex(RuntimeError, "did not consult a source"):
                main.invoke_agent(history)

    def test_follow_up_can_reuse_a_cited_rule_from_tool_history(self):
        history = [HumanMessage(content="What does Blocker do?"),
            ToolMessage(name="search_rules", tool_call_id="rules-1", content=(
                "Comprehensive Rules p. 24\n10-1-4-1. Activate by resting this card."
            )), AIMessage(content="It redirects an attack."),
            HumanMessage(content="Can an already-rested character activate Blocker?")]
        answer = "No. Rule 10-1-4-1 requires resting the card to activate Blocker."
        with patch.object(main, "agent") as agent:
            agent.invoke.return_value = {"messages": [*history, AIMessage(content=answer)]}
            result, returned_history = main.invoke_agent(history)
        self.assertEqual(result, answer)
        self.assertIsInstance(returned_history[1], ToolMessage)

    def test_prior_assistant_citation_alone_cannot_validate_follow_up(self):
        history = [HumanMessage(content="What does Blocker do?"),
            AIMessage(content="Rule 10-1-4-1 says it redirects attacks."),
            HumanMessage(content="Can a rested character activate it?")]
        with patch.object(main, "agent") as agent:
            agent.invoke.return_value = {"messages": [*history, AIMessage(
                content="No, according to 10-1-4-1."
            )]}
            with self.assertRaisesRegex(RuntimeError, "did not consult a source"):
                main.invoke_agent(history)

    def test_previous_rule_does_not_validate_an_invented_citation(self):
        history = [HumanMessage(content="What does Blocker do?"),
            ToolMessage(name="search_rules", tool_call_id="rules-1",
                        content="10-1-4-1. Activate by resting this card."),
            AIMessage(content="It redirects attacks."), HumanMessage(content="Explain another ability.")]
        with patch.object(main, "agent") as agent:
            agent.invoke.return_value = {"messages": [*history, AIMessage(
                content="Rule 122 prevents the opponent from playing cards."
            )]}
            with self.assertRaisesRegex(RuntimeError, "previously retrieved rule"):
                main.invoke_agent(history)

    def test_reused_citation_must_match_the_whole_rule_number(self):
        history = [HumanMessage(content="What does Blocker do?"),
            ToolMessage(name="search_rules", tool_call_id="rules-1",
                        content="10-1-4. [Blocker]\n10-1-4-1. Activate by resting this card."),
            AIMessage(content="It redirects attacks."), HumanMessage(content="What about another case?")]
        with patch.object(main, "agent") as agent:
            agent.invoke.return_value = {"messages": [*history, AIMessage(
                content="See rule 10-1-4-99 for an exception."
            )]}
            with self.assertRaisesRegex(RuntimeError, "previously retrieved rule"):
                main.invoke_agent(history)

    def test_nonexistent_card_cannot_be_answered_from_rules_search(self):
        question = HumanMessage(content="What is OP99-999’s power?")
        with patch.object(main, "agent") as agent:
            agent.invoke.return_value = {"messages": [question,
                ToolMessage(content="Rule 10-1-7-1", name="search_rules", tool_call_id="rules-1"),
                AIMessage(content="OP99-999 has 1000 power.")]}
            with self.assertRaisesRegex(RuntimeError, "did not verify OP99-999"):
                main.invoke_agent([question])

    def test_card_not_found_result_overrides_invented_power(self):
        question = HumanMessage(content="What is OP99-999’s power?")
        missing = "The OPTCG card API returned no card for ID OP99-999."
        with patch.object(main, "agent") as agent:
            agent.invoke.return_value = {"messages": [question,
                ToolMessage(content=missing, name="lookup_card", tool_call_id="card-1"),
                AIMessage(content="OP99-999 has 1000 power.")]}
            result, history = main.invoke_agent([question])
        self.assertEqual(result, missing)
        self.assertNotIn("1000", result)

    def test_lookup_for_different_card_does_not_validate_requested_card(self):
        question = HumanMessage(content="What is OP99-999’s power?")
        with patch.object(main, "agent") as agent:
            agent.invoke.return_value = {"messages": [question,
                ToolMessage(content="API source: https://optcgapi.com/api/sets/card/OP01-001/",
                            name="lookup_card", tool_call_id="card-1"),
                AIMessage(content="OP99-999 has 5000 power.")]}
            with self.assertRaisesRegex(RuntimeError, "did not verify OP99-999"):
                main.invoke_agent([question])

    def test_failed_tool_call_does_not_validate_answer(self):
        question = HumanMessage(content="What is OP99-999’s power?")
        with patch.object(main, "agent") as agent:
            agent.invoke.return_value = {"messages": [question,
                ToolMessage(content="Network unavailable", name="lookup_card", tool_call_id="card-1", status="error"),
                AIMessage(content="OP99-999 has 1000 power.")]}
            with self.assertRaisesRegex(RuntimeError, "did not consult a source"):
                main.invoke_agent([question])


if __name__ == "__main__":
    unittest.main()
