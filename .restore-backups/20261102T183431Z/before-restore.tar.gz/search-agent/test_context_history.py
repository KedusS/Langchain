"""Check that older RAG context is trimmed without breaking conversation history."""

import unittest
from unittest.mock import patch

from langchain_core.messages import AIMessage, HumanMessage, ToolMessage

import main


class ConversationContextTests(unittest.TestCase):
    def test_old_context_is_condensed_and_recent_evidence_and_tool_pairs_survive(self):
        card_url = "https://optcgapi.com/api/sets/card/OP01-001/"
        rules_url = "https://en.onepiece-cardgame.com/pdf/rule_comprehensive.pdf"
        qa_url = "https://en.onepiece-cardgame.com/pdf/qa_rules.pdf"
        first_question = "What is OP01-001’s power?"
        second_question = "What is OP01-012’s power?"
        previous_question = "What does Blocker do?"
        current_question = "Can it activate while already rested?"
        first_references = {
            "cards": {"OP01-001": f"Power: 5000\nAPI source: {card_url}"},
            "rules": "ARCHIVE_ONLY_ONE: old retrieved rules text",
        }
        second_references = {
            "cards": {"OP01-012": "Power: 4000"},
            "rules": "ARCHIVE_ONLY_TWO: another old rules passage",
        }
        previous_rules = (
            f"Comprehensive Rules p. 24 (relevance 0.8; PDF: {rules_url})\n"
            "10-1-4. [Blocker]\n10-1-4-1. Activate by resting this card."
        )
        current_rules = (
            f"Rules Q&A p. 5 (relevance 0.9; PDF: {qa_url})\n"
            "Can I activate the [Blocker] of a rested Character? No, you cannot."
        )
        first = HumanMessage(
            content=(
                "Earlier expanded question\n\nCard API reference retrieved for this question:\n"
                "ARCHIVE_ONLY_ONE: full card and rules records"
            ),
            additional_kwargs={"original_question": first_question, "references": first_references},
        )
        # This older turn predates original_question metadata and needs fallback extraction.
        second = HumanMessage(
            content=(
                f"Question: {second_question}\n\nCard API reference retrieved for this question:\n"
                "ARCHIVE_ONLY_TWO: full card and rules records"
            ),
            additional_kwargs={"references": second_references},
        )
        previous = HumanMessage(
            content=(
                f"Question: {previous_question}\n\nCard API reference retrieved for this question:\n"
                f"No card ID was specified.\n\nOfficial reference retrieved for this question:\n{previous_rules}"
            ),
            additional_kwargs={
                "original_question": previous_question,
                "references": {"cards": {}, "rules": previous_rules},
            },
        )
        tool_request = AIMessage(content="", tool_calls=[{
            "id": "old-card-lookup", "name": "lookup_card",
            "args": {"card_id": "OP01-001", "field": "power"},
        }])
        tool_result = ToolMessage(
            name="lookup_card", tool_call_id="old-card-lookup",
            content=f"Power: 5000\nAPI source: {card_url}",
        )
        history = [
            first, tool_request, tool_result, AIMessage(content="OP01-001 has 5000 power."),
            second, AIMessage(content="OP01-012 has 4000 power."),
            previous, AIMessage(content="Blocker redirects an attack by resting the card."),
            HumanMessage(content=current_question),
        ]
        model_answer = "No. An already-rested character cannot activate Blocker."

        with (
            patch.object(main, "search_rules") as search,
            patch.object(main, "lookup_card") as lookup,
            patch.object(main, "agent") as agent,
        ):
            search.invoke.return_value = current_rules
            agent.invoke.side_effect = lambda payload: {"messages": [
                *payload["messages"], AIMessage(content=model_answer),
            ]}
            answer, returned_history = main.invoke_agent(history)

        sent = agent.invoke.call_args.args[0]["messages"]
        human_turns = [message for message in sent if isinstance(message, HumanMessage)]
        self.assertEqual([message.text for message in human_turns[:2]],
                         [first_question, second_question])
        self.assertEqual(human_turns[2].text, previous.text)
        self.assertIn(current_question, human_turns[3].text)
        self.assertIn(current_rules, human_turns[3].text)
        self.assertEqual(human_turns[0].additional_kwargs["references"], first_references)
        self.assertEqual(human_turns[1].additional_kwargs["references"], second_references)
        self.assertEqual(human_turns[0].additional_kwargs["original_question"], first_question)
        self.assertEqual(human_turns[3].additional_kwargs["original_question"], current_question)
        self.assertEqual(human_turns[3].additional_kwargs["references"]["rules"], current_rules)

        # Condensing HumanMessage content must not remove or orphan actual tool interactions.
        self.assertEqual(sent[1], tool_request)
        self.assertEqual(sent[2], tool_result)
        self.assertEqual(sent[1].tool_calls[0]["id"], sent[2].tool_call_id)
        self.assertEqual(len(sent), len(history))
        search.invoke.assert_called_once_with({"query": current_question})
        lookup.invoke.assert_not_called()
        self.assertIn(model_answer, answer)
        self.assertIn(qa_url, answer)
        self.assertFalse(main._needs_text_answer(answer))
        self.assertEqual(returned_history[-1].text, answer)
        # Preparing a bounded model input must not rewrite the caller's existing history.
        self.assertIn("ARCHIVE_ONLY_ONE", history[0].text)
        self.assertIn("ARCHIVE_ONLY_TWO", history[4].text)


if __name__ == "__main__":
    unittest.main()
