import json
import os
import re
from typing import Sequence

from dotenv import load_dotenv
from langchain.agents import create_agent
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, ToolMessage
from langchain_ollama import ChatOllama

from tools import CARD_API_URL, OLLAMA_BASE_URL, RULE_SECTION_PATTERN, lookup_card, search_rules

load_dotenv()

PDF_REFERENCE_PATTERN = re.compile(
    r"(Comprehensive Rules|Rules Q&A) p\. (\d+) \([^\n]*?PDF: (https://en\.onepiece-cardgame\.com/[^\s)]+)\)"
)
PDF_SOURCE_PATTERN = re.compile(r"PDF: (https://en\.onepiece-cardgame\.com/[^\s)]+)")

SYSTEM_PROMPT = """You are a One Piece Card Game rules assistant.
Use the supplied official references and card API records, including references
from earlier turns. Call search_rules or lookup_card only when information is missing.
For a specific ruling, search with the full question and prefer an official
Rules Q&A answer that directly addresses it. Do not add a reason the Q&A does not give.
For printed card stats, copy the corresponding API field, not numbers in card effects.
Null means no value is provided, not zero. Event cards have no printed power.
Describe missing values in ordinary language as unavailable or not applicable.
If the API reports no card, say it was not found. Do not invent stats or rulings.
Apply both the timing conditions and required activation actions; timing alone
does not waive an action or cost. Ask for missing details when the situation is unclear.
Give a short natural-language answer with source links. Do not output JSON,
code blocks, or tool requests. If the references do not support an answer, say so."""

llm = ChatOllama(
    model=os.getenv("OLLAMA_CHAT_MODEL", "qwen3:1.7b"),
    base_url=OLLAMA_BASE_URL,
    temperature=0,
    reasoning=False,
    num_ctx=8192,
    num_predict=384,
)

agent = create_agent(
    model=llm,
    tools=[search_rules, lookup_card],
    system_prompt=SYSTEM_PROMPT,
)


def _needs_text_answer(text: str) -> bool:
    if "```" in text or re.search(r"\b(?:lookup_card|search_rules)\s*\(", text):
        return True
    plain = text.strip()
    starts_with_link = bool(re.match(r"^\[[^\]\n]+\]\(", plain))
    if not starts_with_link and re.match(r'^\s*(?:\{\s*"|\[\s*(?:\{|"|\[))', text):
        return True
    decoder = json.JSONDecoder()
    for start in re.finditer(r"[\[{]", text):
        try:
            payload, _ = decoder.raw_decode(text[start.start():])
        except ValueError:
            continue
        if isinstance(payload, dict):
            return True
        if isinstance(payload, list):
            leading = not text[:start.start()].strip()
            if leading and starts_with_link:
                continue
            if leading or any(isinstance(item, (dict, list)) for item in payload):
                return True
    return False


def _cites_rules(answer: str, reference: str) -> bool:
    return any(source in answer for source in PDF_SOURCE_PATTERN.findall(reference)) or any(
        re.search(r"(?<![\d-])" + re.escape(section) + r"(?![\d-])", answer)
        for section in RULE_SECTION_PATTERN.findall(reference)
    )


def invoke_agent(messages: Sequence[BaseMessage]) -> tuple[str, list[BaseMessage]]:
    question_index = next((i for i in range(len(messages) - 1, -1, -1)
                           if isinstance(messages[i], HumanMessage)), -1)
    if question_index < 0:
        raise ValueError("Ask an OPTCG question first.")
    question = messages[question_index].text
    card_ids = set(re.findall(r"\b[A-Z0-9]{1,6}-\d{3}\b", question.upper()))
    card_context = {}
    for card_id in sorted(card_ids):
        content = lookup_card.invoke({"card_id": card_id})
        if content:
            card_context[card_id] = content
    card_evidence = "\n\n".join(card_context.values()) or "No card ID was specified."
    rules_context = search_rules.invoke({"query": question})
    model_messages = list(messages)
    # Keep the last reference turn for follow-ups; older turns keep their metadata.
    previous_questions = [i for i in range(question_index) if isinstance(messages[i], HumanMessage)]
    for index in previous_questions[:-1]:
        previous = messages[index]
        if "references" not in previous.additional_kwargs:
            continue
        original_question = previous.additional_kwargs.get("original_question")
        if not isinstance(original_question, str):
            original_question = previous.text.split("\n\nCard API reference retrieved for this question:", 1)[0]
            original_question = original_question.removeprefix("Question: ")
        model_messages[index] = previous.model_copy(update={"content": original_question})
    model_messages[question_index] = messages[question_index].model_copy(update={
        "content": (
            f"Question: {question}\n\nCard API reference retrieved for this question:\n"
            f"{card_evidence}\n\n"
            f"Official reference retrieved for this question:\n{rules_context}"
        ),
        "additional_kwargs": {
            **messages[question_index].additional_kwargs,
            "original_question": question,
            "references": {"cards": card_context, "rules": rules_context},
        },
    })
    result = agent.invoke({"messages": model_messages})
    output_messages = result.get("messages", [])
    if output_messages and isinstance(output_messages[-1], AIMessage) and _needs_text_answer(output_messages[-1].text):
        # One correction with the same agent; never execute JSON from plain text.
        retry_messages = list(model_messages)
        retry_messages[question_index] = model_messages[question_index].model_copy(update={"content": (
            model_messages[question_index].text + "\n\nThe card and rules references are already "
            "provided above. Give the final answer in plain language. Do not print a tool "
            "request, JSON, or code block. Use actual tool calling only if more evidence is needed."
        )})
        result = agent.invoke({"messages": retry_messages})
        output_messages = result.get("messages", [])
        if output_messages and isinstance(output_messages[-1], AIMessage) and _needs_text_answer(output_messages[-1].text):
            raise RuntimeError("The model did not produce a text answer after one correction. Please try again.")
    if not output_messages:
        raise RuntimeError("The agent did not finish its answer. Please try again.")
    # Keep retrieved evidence in agent history, but remove the format-correction instruction.
    if question_index < len(output_messages) and isinstance(output_messages[question_index], HumanMessage):
        output_messages[question_index] = output_messages[question_index].model_copy(
            update={
                "content": model_messages[question_index].content,
                "additional_kwargs": model_messages[question_index].additional_kwargs,
            }
        )
    final_message = output_messages[-1]
    if (
        not isinstance(final_message, AIMessage)
        or final_message.tool_calls
        or not final_message.text.strip()
    ):
        raise RuntimeError("The agent did not finish its answer. Please try again.")
    tool_results = [message for message in output_messages
                    if isinstance(message, ToolMessage) and message.status != "error"]
    fresh_tools = [message for message in output_messages[len(messages):]
                   if isinstance(message, ToolMessage) and message.status != "error"]
    cited_history_reference = False
    cited_history_rules = []
    for message in messages[:question_index]:
        if not isinstance(message, HumanMessage):
            continue
        reference = message.additional_kwargs.get("references", {})
        if not isinstance(reference, dict):
            continue
        cards = reference.get("cards", {})
        rules = reference.get("rules", "")
        if not isinstance(cards, dict) or not isinstance(rules, str):
            continue
        for card_id, content in cards.items():
            source = CARD_API_URL.format(card_id=card_id)
            if isinstance(content, str) and f"API source: {source}" in content and source in final_message.text:
                cited_history_reference = True
        if _cites_rules(final_message.text, rules):
            cited_history_reference = True
            cited_history_rules.append(rules)
    cited_history_rules.extend(
        message.text for message in tool_results
        if message.name == "search_rules" and _cites_rules(final_message.text, message.text)
    )
    if not (PDF_REFERENCE_PATTERN.search(rules_context) or card_context or fresh_tools
            or cited_history_reference or cited_history_rules):
        raise RuntimeError(
            "The agent did not consult a source or cite a previously retrieved rule, "
            "so its answer was not shown. Please try again."
        )
    for card_id in card_ids:
        not_found = f"The OPTCG card API returned no card for ID {card_id}."
        source = f"API source: {CARD_API_URL.format(card_id=card_id)}"
        current_card = card_context.get(card_id)
        if not current_card:
            current_card = next((message.text for message in reversed(tool_results)
                                 if message.name == "lookup_card" and
                                 (source in message.text or not_found in message.text)), "")
        if not_found in current_card:
            output_messages[-1] = final_message.model_copy(update={"content": not_found})
            return not_found, output_messages
        if source not in current_card:
            raise RuntimeError(
                f"The agent did not verify {card_id} with lookup_card, so its answer was not shown."
            )
    answer = final_message.text
    for card_id in sorted(card_ids):
        source = CARD_API_URL.format(card_id=card_id)
        if source not in answer:
            answer += f"\n\n[{card_id} card data]({source})"
    # Source links come from actual tool output, even if the model omits them.
    references = ([rules_context] if not card_ids else []) + [
        message.text for message in fresh_tools if message.name == "search_rules"
    ] + cited_history_rules
    for reference in references:
        for title, page, source in PDF_REFERENCE_PATTERN.findall(reference):
            if source not in answer:
                answer += f"\n\n[{title}, p. {page}]({source}#page={page})"
    output_messages[-1] = final_message.model_copy(update={"content": answer})
    return answer, output_messages


def main() -> None:
    question = input("Ask an OPTCG rules or card question: ")
    answer, _ = invoke_agent([HumanMessage(content=question)])
    print(answer)


if __name__ == "__main__":
    main()
