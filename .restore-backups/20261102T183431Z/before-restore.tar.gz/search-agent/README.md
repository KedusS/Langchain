# OPTCG Rules Assistant

A course-style LangChain assistant for One Piece Card Game rules and printed
card data. Answers are ordinary text with source links.

The project uses the same core concepts as Eden Marco's
[search-agent example](https://github.com/emarco177/langchain-course/blob/project/search-agent/main.py)
and [RAG project](https://github.com/emarco177/langchain-course/tree/project/rag-gist):

| Part | Implementation |
| --- | --- |
| Model | `ChatOllama` with `qwen3:1.7b` |
| Agent | `create_agent` with two custom `@tool` functions |
| Rules retrieval | Official PDFs, text splitting, local Ollama embeddings, Chroma |
| Card data | Public OPTCG card API |
| Conversation | LangChain messages stored in Streamlit session state |
| Output | Natural-language text and source links |

Before an answer, the app retrieves rules references and card records for any
explicit card IDs. The agent uses that context and can call its tools for more
information. It still generates the answer. This combines ordinary RAG with
tool calling, without requiring the small model to initiate every lookup.

The rules index contains the official Comprehensive Rules and Rules Q&A PDFs.
The Q&A provides explicit answers for situations such as a rested Blocker.
Printed card stats come from the card API, rather than numbers in card effects.
Event cards have no printed power; missing data is not treated as zero.

The chat display stores the user's original questions and text answers.
Agent history separately retains the supplied references, model messages, and
actual tool results so follow-up questions can use earlier evidence.
The model sees the latest reference turns in full. Older questions retain their
source metadata without repeatedly sending all of their reference text, helping
the conversation fit the local model's context window.
**New conversation** clears both histories.

JSON, code blocks, and printed tool requests are rejected as final answers.
The same agent gets one correction attempt using the already retrieved context;
a repeated failure produces a text error. Serialized requests are never executed
as code. These are small Python response checks around the course components.

## Setup

Requires Python 3.11+ and [uv](https://docs.astral.sh/uv/).

If `uv` is not installed, install it on Linux/macOS and add it to the current
shell's `PATH`:

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
export PATH="$HOME/.local/bin:$PATH"
uv --version
```

Alternatively, open a new terminal after the installer finishes, then check
that `uv --version` works.

From the repository root, enter the project directory and install dependencies:

```bash
cd search-agent
uv sync
```

Install and start [Ollama](https://ollama.com/download) on the same machine
where this app is running. Pull one chat model and one embedding model:

```bash
ollama pull qwen3:1.7b
ollama pull nomic-embed-text
```

Start the Ollama server in a separate Codespace terminal and leave that terminal
running:

```bash
ollama serve
```

By default, the app connects to `http://localhost:11434`.
If you are using Codespaces or another remote dev container, Ollama must be
running inside that environment or `OLLAMA_BASE_URL` must point to a server it
can reach; `localhost` refers to the dev container, not your personal computer.
Optionally configure a different server or model names in a `.env` file:

```dotenv
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_CHAT_MODEL=qwen3:1.7b
OLLAMA_EMBEDDING_MODEL=nomic-embed-text
```

Download and index the current Comprehensive Rules and Rules Q&A PDFs linked
from the official rules and FAQ pages. This also creates a local Chroma database in `chroma/`:

```bash
uv run python ingestion.py
```

Start the chat UI:

```bash
uv run streamlit run streamlit_app.py
```

Both the chat model and embeddings run locally through Ollama; no OpenAI API key
or paid model API is used. The first ingestion downloads the rules PDF and
creates local embeddings, which can take a few minutes. The `search_rules` tool
uses the local Chroma index containing both official documents. Explicit Rules
Q&A answers are preferred when they directly address the question. `lookup_card` uses the public, unauthenticated
[OPTCG API](https://optcgapi.com/documentation) and accepts IDs such as
`OP01-001` or `P-001`. Neither tool requires a separate API key. The rules PDF
and Chroma database are local files and are excluded from version control.

To refresh the local rules index when the official PDF changes, run
`uv run python ingestion.py` again.

Run the agent-response and UI checks with:

```bash
uv run python -m unittest test_rules_grounding.py
```

The regression checks use mocked model/API responses to test wiring, history,
source handling, and text output. Verify live conversations as well: card power,
an Event card with no printed power, a missing card, Blocker, and a rested-Blocker
follow-up. Model answers still need to be checked against the cited official
sources; these checks do not prove every possible ruling is correct.

## CLI

For a one-question terminal session instead of Streamlit:

```bash
uv run python main.py
```

