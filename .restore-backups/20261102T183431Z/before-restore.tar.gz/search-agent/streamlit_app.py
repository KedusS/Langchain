import streamlit as st
from httpx import ConnectError, HTTPError
from langchain_core.messages import HumanMessage
from langgraph.errors import GraphRecursionError
from requests.exceptions import RequestException
from ollama import ResponseError

from main import invoke_agent
from tools import CHROMA_DIR, OLLAMA_BASE_URL, RULES_PAGE_URL

st.set_page_config(page_title="OPTCG Rules Assistant", page_icon="🏴‍☠️")
st.title("OPTCG Rules Assistant")
st.caption("Explain a One Piece Card Game situation. The agent checks the official rules and relevant card text.")

if st.sidebar.button("New conversation"):
    st.session_state.messages = []
    st.session_state.agent_messages = []
    st.rerun()

if not CHROMA_DIR.is_dir():
    st.sidebar.warning("Rules index missing. Run `uv run python ingestion.py` first.")
st.sidebar.markdown(f"[Official rules page]({RULES_PAGE_URL})")

if "messages" not in st.session_state:
    st.session_state.messages = []
if "agent_messages" not in st.session_state:
    st.session_state.agent_messages = []

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["answer"])

question = st.chat_input()
if question:
    st.session_state.messages.append({"role": "user", "answer": question})
    with st.chat_message("user"):
        st.markdown(question)

    history = [*st.session_state.agent_messages, HumanMessage(content=question)]
    with st.chat_message("assistant"):
        with st.spinner("Checking the rules and card database..."):
            try:
                answer, agent_messages = invoke_agent(history)
            except ConnectError:
                st.error(
                    f"Can't connect to Ollama at `{OLLAMA_BASE_URL}`. "
                    "Start `ollama serve`, or check your OLLAMA_BASE_URL setting."
                )
                st.stop()
            except (HTTPError, RequestException, ResponseError, RuntimeError, ValueError, GraphRecursionError) as error:
                st.error(f"Unable to complete the lookup: {error}")
                st.stop()
        st.markdown(answer)

    st.session_state.messages.append({"role": "assistant", "answer": answer})
    st.session_state.agent_messages = agent_messages
